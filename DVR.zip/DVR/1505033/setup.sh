sudo ifconfig wlp2s0:1 192.168.0.1 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:2 192.168.0.2 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:3 192.168.0.3 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:4 192.168.0.4 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:100 192.168.0.100 netmask 255.255.255.0 up
