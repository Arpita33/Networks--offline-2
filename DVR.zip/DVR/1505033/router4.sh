g++ -o router.out router.cpp
./router.out 192.168.0.4 topo2.txt

