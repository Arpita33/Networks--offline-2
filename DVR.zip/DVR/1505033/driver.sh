python driver.py topo2.txt

