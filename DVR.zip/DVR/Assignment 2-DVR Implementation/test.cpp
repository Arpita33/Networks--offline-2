#include "stdio.h"
#include <cstring>
#include <cstdlib>
#include<vector>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fstream>
#include<iostream>
#include <sstream>
#include <algorithm>



int main(int argc, char *argv[]){


	int sockfd;
	int bind_flag;
	char buffer[1024];
	int bytes_received;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	if(argc != 3){
		//printf("%s <ip address>\n", argv[0]);
		printf("Invalid arguments\n");
		exit(1);
	}


	client_address.sin_family = AF_INET;
	client_address.sin_port = htons(4747);
	client_address.sin_addr.s_addr = inet_addr(argv[1]);

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	bind_flag = bind(sockfd, (struct sockaddr*) &client_address, sizeof(sockaddr_in));
	printf("bind-flag = %d\n",bind_flag);
	//printf("This is working\n");
	//buffer = new char[8];
	while(true){

		bytes_received = 0;
		bytes_received = recv(sockfd, buffer, 1024, 0);
		string temp(buffer);
		if(temp.substr(0,4)=="send"){
		//buffer[bytes_received]='\0';
		cout<<buffer<<endl;
		cout<<temp<<endl;
		int a[5];
		string str="hello";
		for(int j=0;j<5;j++)
		{
			a[j]=str[j];
			cout<<str[j]<<".";
		}
		
		//unsigned char temp[]=(unsigned char) buffer;
		//printf("Content: %s\nBytes: %d\n",buffer,bytes_received);

		}
	}

	close(sockfd);
	
	Router router=Router(argv[1],argv[2]);

	return 0;

}
