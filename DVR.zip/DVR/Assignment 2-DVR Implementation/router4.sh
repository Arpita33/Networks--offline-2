g++ -o router.out router.cpp
./router.out 172.20.57.4 topo3.txt

