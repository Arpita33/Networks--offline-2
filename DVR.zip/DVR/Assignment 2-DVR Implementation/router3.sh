g++ -o router.out router.cpp
./router.out 172.20.57.3 topo3.txt
