sudo ifconfig wlp2s0:1 172.20.57.1 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:2 172.20.57.2 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:3 172.20.57.3 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:4 172.20.57.4 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:100 172.20.57.100 netmask 255.255.255.0 up
