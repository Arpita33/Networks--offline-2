g++ -o router4.out 1505033_router.cpp
./router4.out 172.20.56.4 topo3.txt

