g++ -o router2.out 1505033_router.cpp
./router2.out 172.20.56.2 topo3.txt

