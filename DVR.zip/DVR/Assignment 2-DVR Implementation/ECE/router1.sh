g++ -o router1.out 1505033_router.cpp
./router1.out 172.20.56.1 topo3.txt
