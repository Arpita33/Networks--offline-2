sudo ifconfig wlp2s0:1 172.20.56.1 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:2 172.20.56.2 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:3 172.20.56.3 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:4 172.20.56.4 netmask 255.255.255.0 up
sudo ifconfig wlp2s0:100 172.20.56.100 netmask 255.255.255.0 up
