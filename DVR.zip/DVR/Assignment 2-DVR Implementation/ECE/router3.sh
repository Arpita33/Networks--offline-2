g++ -o router3.out 1505033_router.cpp
./router3.out 172.20.56.3 topo3.txt
