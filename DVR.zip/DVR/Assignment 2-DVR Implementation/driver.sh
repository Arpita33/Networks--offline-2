python driver.py topo3.txt

