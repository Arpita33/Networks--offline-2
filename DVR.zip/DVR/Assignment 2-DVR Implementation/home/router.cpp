#include "stdio.h"
#include <cstring>
#include <cstdlib>
#include<vector>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fstream>
#include<iostream>
#include <sstream>
#include <algorithm>
#include <limits>


#define INF 1000000


using namespace std;
class Node
{public:
	string dest;
	string next_hop;
	int cost;
	Node(string d, string nh, int c)
	{
		dest=d;
		next_hop=nh;
		cost=c;
	}
};
class NeighbourInfo
{
public:
	string neighbour_ip;
	int link_cost;
	int link_status;
	int time_stamp;
	NeighbourInfo(string a, int b)
	{
		neighbour_ip=a;
		link_cost=b;
		link_status=1;
	}
};
class Router
{
vector<Node> routing_table;
string ip;
vector<string> all_ips;
vector<NeighbourInfo> adjacent;
public:
	Router(string ip_address, string filename)
	{
		ip=ip_address;
		all_ips.push_back(ip);
		ifstream file(filename);
    		string str; 
    		while (getline(file, str))
    		{
			stringstream ss(str);
			string s;
			vector<string> tokens;
			while (getline(ss, s, ' ')) {
			 //cout << s << endl;
			tokens.push_back(s);
	
			}
			if(tokens.at(0).compare(ip)==0)
			{
				

				stringstream num(tokens.at(2));
				int x = 0; 
    				num >> x; 
				Node n=Node(tokens.at(1),tokens.at(1),x);
				routing_table.push_back(n);
				if (find(all_ips.begin(), all_ips.end(), tokens.at(1)) == all_ips.end())
				{
					all_ips.push_back(tokens.at(1));
				  
				}
				//cout<<"Pushing in neighbours!";
				NeighbourInfo ni=NeighbourInfo(tokens.at(1),x);
				adjacent.push_back(ni);
				
			}
			else if(tokens.at(1).compare(ip)==0)
			{
				stringstream num(tokens.at(2));
				int x = 0; 
    				num >> x; 
				Node n=Node(tokens.at(0),tokens.at(0),x);
				routing_table.push_back(n);
				if (find(all_ips.begin(), all_ips.end(), tokens.at(0)) == all_ips.end())
				{
					all_ips.push_back(tokens.at(0));
				  
				}
				//cout<<"Pushing in neighbours!";
				NeighbourInfo ni=NeighbourInfo(tokens.at(0),x);
				adjacent.push_back(ni);
				
			}
			else
			{
				if (find(all_ips.begin(), all_ips.end(), tokens.at(0)) == all_ips.end())
				{
					all_ips.push_back(tokens.at(0));
				  
				}
				if (find(all_ips.begin(), all_ips.end(), tokens.at(1)) == all_ips.end())
				{
					all_ips.push_back(tokens.at(1));
				  
				}
			}
			
			
    		}
    		
    		for(int i=0;i<all_ips.size();i++)
    		{
    			

			string ip_under_consideration=all_ips.at(i);
			if(ip_under_consideration.compare(ip)!=0)
			{
				int flag=0;
				for(int j=0;j<adjacent.size();j++)
				{
					if(adjacent.at(j).neighbour_ip.compare(ip_under_consideration)==0)
					{
						flag=1;
						break;
					}
				}
				if(flag==0)
				{
						Node n=Node(all_ips.at(i),"-----------",INF);
						routing_table.push_back(n);
				}
			}
    			
    		}
    		show_routing_table();
    		show_neighbour_list();
	
       
   
	}
	
	void show_routing_table()
	{
		cout<<"-------ROUTING TABLE for ip: "<<ip<<"--------"<<endl;
		cout<<"DESTINATION\tNEXT HOP\tCOST"<<endl;
		for(int i=0;i<routing_table.size();i++)
		{
			Node node=routing_table.at(i);
			cout<<node.dest<<"\t"<<node.next_hop<<"\t"<<node.cost<<endl;
		}
		cout<<endl;
	}
	void show_neighbour_list()
	{
		cout<<"-----Neighbour list for ip: "<<ip<<"-----"<<endl;
		cout<<"Neighbour\tLink Cost\tLink Status\tTime Stamp"<<endl;
		for(int i=0;i<adjacent.size();i++)
		{
			NeighbourInfo ni=adjacent.at(i);
			cout<<ni.neighbour_ip<<"\t"<<ni.link_cost<<"\t\t"<<ni.link_status<<"\t\t"<<ni.time_stamp<<endl;
		}
		cout<<endl;
	}
	
	void send_packets(string dest_ip, char* buffer, int no_of_bytes)
	{
		int size=no_of_bytes-4;
		char new_buf[size];
		new_buf[0]='f';
		new_buf[1]='r';
		new_buf[2]='w';
		new_buf[3]='d';
		for(int i=8;i<size+4;i++)
		{
			new_buf[i-4]=buffer[i];
		}
		forward_packets(dest_ip, new_buf, size);
	}
	
	
	
	void forward_packets(string dest_ip, char* buffer, int no_of_bytes)
	{
		unsigned char c1=(unsigned char)buffer[9];
		int MSB=(int)c1;
		unsigned char c2=(unsigned char)buffer[8];
		int LSB=(int)c2;
		int len=MSB<<8|LSB;
		printf("Message length=%d\n",len);
		string message="";
		for(int i=0;i<len;i++)
		{
			char a=buffer[i+10];
			message+=a;
		}

		if(dest_ip.compare(this->ip)==0)
		{
			printf("{%s} packet of length %d reached destination (printed by %s)\n",message.c_str(),len,this->ip.c_str());
		}
		else{
		for(int i=0;i<routing_table.size();i++)
		{
			Node rt_entry=routing_table.at(i);
			if(dest_ip.compare(rt_entry.dest)==0)
			{
				
				if(rt_entry.cost!=INF)
				{
					struct sockaddr_in router2_address;
					router2_address.sin_family = AF_INET;
					router2_address.sin_port = htons(4747);
					router2_address.sin_addr.s_addr = inet_addr(rt_entry.next_hop.c_str());
					int sockfd;
					
					sockfd = socket(AF_INET, SOCK_DGRAM, 0);

					
					sendto(sockfd, buffer, 1024, 0, (struct sockaddr*) &router2_address, sizeof(sockaddr_in));
					printf("{%s} packet of length %d forwarded to %s (printed by %s)\n",message.c_str(),len,rt_entry.next_hop.c_str(),this->ip.c_str());
				}
				else
				{
					printf("Destination not accessible!! \n");
					
				}
				
			}
		    }
		}
	}
	
	vector<string> getTokens(string str, char delim)
	{
		stringstream ss(str);
		string s;
		vector<string> tokens;
		while (getline(ss, s, delim)) {
			
		 	tokens.push_back(s);
	
		}
		return tokens;
	}
	int string_to_num(string str)
	{
		stringstream num(str);
		int x = 0; 
    		num >> x;
    		return x;
	}
	void transmit(string destination_ip,const char* buffer)
	{
		struct sockaddr_in router2_address;
		router2_address.sin_family = AF_INET;
		router2_address.sin_port = htons(4747);
		router2_address.sin_addr.s_addr = inet_addr(destination_ip.c_str());
		int sockfd;
		sockfd = socket(AF_INET, SOCK_DGRAM, 0);
		sendto(sockfd, buffer, 1024, 0, (struct sockaddr*) &router2_address, sizeof(sockaddr_in));
	}

	
	
	
	void send_rt_to_neighbours2()
	{
		string message="";
		message+="ni$"+this->ip+"$";
		for(int i=0;i<this->routing_table.size();i++)
		{
		
			Node rt_entry=routing_table.at(i);
			string ip1=rt_entry.dest;
			string ip2=rt_entry.next_hop;
			int c=rt_entry.cost;
			message+=ip1;
			message+="#";
			message+=ip2;
			message+="#";
			message+=to_string(c);
			message+="$";
			
		}
		//printf("%s",message.c_str());
		for(int i=0;i<this->adjacent.size();i++)
		{
			NeighbourInfo adj_entry=adjacent.at(i);
			transmit(adj_entry.neighbour_ip,message.c_str());
			//printf("Sent routing table to ip: %s.\n",adj_entry.neighbour_ip.c_str());
			
			
			
		}
	}
	
	
	
	
	
	
	string receive_neighbour_rt(string message)
	{
		
		vector<string> neighbour_info=getTokens(message,'$');
		vector<Node> neighbour_rt;
		string sender_ip=neighbour_info.at(1);
		//printf("Received routing table from ip: %s\n",sender_ip.c_str());
		for(int i=2;i<neighbour_info.size();i++)
		{
			//cout<<neighbour_info.at(i)<<endl;
			vector<string> entry_parts=getTokens(neighbour_info.at(i),'#');
			Node node=Node(entry_parts.at(0),entry_parts.at(1),string_to_num(entry_parts.at(2)));
			neighbour_rt.push_back(node);
			
		}
		/*printf("Routing table of %s\n",sender_ip.c_str());
		for(int i=0;i<neighbour_rt.size();i++)
		{
			Node node=neighbour_rt.at(i);
			cout<<node.dest<<" "<<node.next_hop<<" "<<node.cost<<endl;
		}*/
		int neighbour_cost;
		string intermediate;
		/*for(int i=0;i<adjacent.size();i++)
		{
			if(adjacent.at(i).neighbour_ip.compare(sender_ip)==0)
			{
				neighbour_cost=adjacent.at(i).link_cost;
				printf("neighbour_cost %d\n",neighbour_cost);
			}
		}*/
		for(int i=0;i<this->routing_table.size();i++)
		{
			Node node=this->routing_table.at(i);
			string destination1=node.dest;
			if(sender_ip.compare(destination1)==0)
			{
				neighbour_cost=node.cost;
				intermediate=node.next_hop;
			}
		}
		for(int i=0;i<this->routing_table.size();i++)
		{
			Node node=this->routing_table.at(i);
			string destination1=node.dest;
			int cost1=node.cost;
			for(int j=0;j<neighbour_rt.size();j++)
			{
				string destination2=neighbour_rt.at(j).dest;
				int cost2=neighbour_rt.at(j).cost;
				if(destination1.compare(destination2)==0)
				{
					if((neighbour_cost+cost2)<cost1)
					{
						
						this->routing_table.at(i).next_hop=intermediate;
						this->routing_table.at(i).cost=neighbour_cost+cost2;
					}
					
				}
			}
		}
		//show_routing_table();
		return sender_ip;
	}
	
	
	void cost_update(string ip1, string ip2, int value)
	{
		
		
		if(ip.compare(ip1)==0)
		{
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip2)==0)
				{
					adjacent.at(i).link_cost=value;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip2)==0)
				{
					if(node.cost>value)
					{
						this->routing_table.at(i).next_hop=ip2;
						this->routing_table.at(i).cost=value;
					}
				}
			}
		}
		else if(ip.compare(ip2)==0)
		{
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip1)==0)
				{
					adjacent.at(i).link_cost=value;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip1)==0)
				{
					if(node.cost>value)
					{
						this->routing_table.at(i).next_hop=ip1;
						this->routing_table.at(i).cost=value;
					}
				}
			}
		}
		
	}
	

	void link_down(string ip1, string ip2)
	{
		if(ip.compare(ip1)==0)
		{
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip2)==0)
				{
					adjacent.at(i).link_status=0;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip2)==0)
				{
					this->routing_table.at(i).next_hop=ip2;
					this->routing_table.at(i).cost=INF;
					
				}
			}
			
		}
		if(ip.compare(ip2)==0)
		{
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip1)==0)
				{
					adjacent.at(i).link_status=0;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip1)==0)
				{
					this->routing_table.at(i).next_hop=ip1;
					this->routing_table.at(i).cost=INF;
					
				}
			}
			
		}
	//show_routing_table();
	//show_neighbour_list();
		
	}
	void link_up(string ip1, string ip2)
	{
		if(ip.compare(ip1)==0)
		{
			int cost_new;
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip2)==0)
				{
					adjacent.at(i).link_status=1;
					cost_new=adjacent.at(i).link_cost;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip2)==0)
				{
					this->routing_table.at(i).next_hop=ip2;
					this->routing_table.at(i).cost=cost_new;;
					
				}
			}
			
		}
		if(ip.compare(ip2)==0)
		{
			int cost_new;
			for(int i=0;i<adjacent.size();i++)
			{
				NeighbourInfo ni=adjacent.at(i);
				if(ni.neighbour_ip.compare(ip1)==0)
				{
					adjacent.at(i).link_status=1;
					cost_new=adjacent.at(i).link_cost;
				}
			}
			for(int i=0;i<this->routing_table.size();i++)
			{
				Node node=this->routing_table.at(i);
				if(node.dest.compare(ip1)==0)
				{
					this->routing_table.at(i).next_hop=ip1;
					this->routing_table.at(i).cost=cost_new;
					
				}
			}
			
		}
	}
	void placeTimeStamp(string source_ip, int clockCounter)
	{
		for(int i=0;i<adjacent.size();i++)
		{
				
			if(adjacent.at(i).neighbour_ip.compare(source_ip)==0)
			{
				if(adjacent.at(i).link_status==0)
				{
					link_up(this->ip,source_ip);
				}
				adjacent.at(i).time_stamp=clockCounter;
					
			}
		}
	}
	void check_for_down_links(int current_timestamp)
	{
		for(int i=0;i<adjacent.size();i++)
		{
			NeighbourInfo ni=adjacent.at(i);
			if((ni.time_stamp-current_timestamp)>3)
			{
				link_down(this->ip,ni.neighbour_ip);
			}
		}
	}
	
	
};


string getIp(int arr[])
{
	string ip;
	ip=to_string(arr[0]);
	ip+=".";
	ip+=to_string(arr[1]);
	ip+=".";
	ip+=to_string(arr[2]);
	ip+=".";
	ip+=to_string(arr[3]);
	return ip;
}




int main(int argc, char *argv[]){

	int clockCounter=0;
	int sockfd;
	int bind_flag;
	char buffer[1024];
	int bytes_received;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	if(argc != 3){
		//printf("%s <ip address>\n", argv[0]);
		printf("Invalid arguments\n");
		exit(1);
	}


	client_address.sin_family = AF_INET;
	client_address.sin_port = htons(4747);
	client_address.sin_addr.s_addr = inet_addr(argv[1]);

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	bind_flag = bind(sockfd, (struct sockaddr*) &client_address, sizeof(sockaddr_in));
	printf("bind-flag = %d\n",bind_flag);

	Router router=Router(argv[1],argv[2]);
	while(true){

		bytes_received = 0;
		bytes_received = recv(sockfd, buffer, 1024, 0);
		//buffer[bytes_received]='\0';
		string temp(buffer);
		if(temp.substr(0,4)=="send")
		{
				
			cout<<buffer<<endl;
			int arr[4];
			int count=0;
			for(int i=4;i<8;i++)
			{
				unsigned char a=(unsigned char)buffer[i];
				int b=(int)a;
				
				arr[count++]=b;
				
				
			}
			
			string ip1;
			ip1=to_string(arr[0]);
			ip1+=".";
			ip1+=to_string(arr[1]);
			ip1+=".";
			ip1+=to_string(arr[2]);
			ip1+=".";
			ip1+=to_string(arr[3]);
			
			//cout<<ip1<<endl;
			count=0;
			for(int i=8;i<12;i++)
			{
				unsigned char a=(unsigned char)buffer[i];
				int b=(int)a;
				
				arr[count++]=b;
				
			}
			string ip2;
			ip2=to_string(arr[0]);
			ip2+=".";
			ip2+=to_string(arr[1]);
			ip2+=".";
			ip2+=to_string(arr[2]);
			ip2+=".";
			ip2+=to_string(arr[3]);
			cout<<ip1<<endl;
			cout<<ip2<<endl;
			router.send_packets(ip2,buffer,bytes_received);
			
		}
		if(temp.substr(0,4)=="frwd")
		{
			int arr[4];
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+4];
				int b=(int)a;
				arr[i]=b;
			}
			string dest_ip=getIp(arr);
			router.forward_packets(dest_ip,buffer,bytes_received);
		}
		if(temp.substr(0,3)=="clk")
		{
			clockCounter++;
			router.check_for_down_links(clockCounter);
			router.send_rt_to_neighbours2();
		}
		if(temp.substr(0,2)=="ni")
		{
			//printf("received routing table\n");
			string source_ip=router.receive_neighbour_rt(temp);
			router.placeTimeStamp(source_ip,clockCounter);
			

		}
		if(temp.substr(0,4)=="cost")
		{
			int arr[4];
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+4];
				int b=(int)a;
				arr[i]=b;
			}
			string ip1=getIp(arr);
			
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+8];
				int b=(int)a;
				arr[i]=b;
			}
			string ip2=getIp(arr);
			unsigned char c1=(unsigned char)buffer[13];
			int MSB=(int)c1;
			unsigned char c2=(unsigned char)buffer[12];
			int LSB=(int)c2;
			int val=MSB<<8|LSB;
			cout<<ip1<<" "<<ip2<<endl;
			printf("value: %d\n",val);
			router.cost_update(ip1,ip2,val);
		}
		if(temp.substr(0,4)=="down")
		{	
			int arr[4];
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+4];
				int b=(int)a;
				arr[i]=b;
			}
			string ip1=getIp(arr);
			
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+8];
				int b=(int)a;
				arr[i]=b;
			}
			string ip2=getIp(arr);
			router.link_down(ip1,ip2);
		}
		if(temp.substr(0,2)=="up")
		{
			int arr[4];
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+2];
				int b=(int)a;
				arr[i]=b;
			}
			string ip1=getIp(arr);
			
			for(int i=0;i<4;i++)
			{
				unsigned char a=(unsigned char)buffer[i+6];
				int b=(int)a;
				arr[i]=b;
			}
			string ip2=getIp(arr);
			router.link_up(ip1,ip2);
		}
		if(temp.substr(0,4)=="show")
		{
			router.show_routing_table();
		}
		
	
}
	close(sockfd);
	
	

	return 0;

}
