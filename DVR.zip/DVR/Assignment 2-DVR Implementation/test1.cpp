#include "stdio.h"
#include <cstring>
#include <cstdlib>
#include<vector>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fstream>
#include<iostream>
#include <sstream>
#include <algorithm>
#include <limits>
using namespace std;
string getIp(int arr[])
{
	string ip;
	ip=to_string(arr[0]);
	ip+=".";
	ip+=to_string(arr[1]);
	ip+=".";
	ip+=to_string(arr[2]);
	ip+=".";
	ip+=to_string(arr[3]);
	return ip;
}
	vector<string> getTokens(string str, char delim)
	{
		stringstream ss(str);
		string s;
		vector<string> tokens;
		while (getline(ss, s, delim)) {
			
		 	tokens.push_back(s);
	
		}
		return tokens;
	}
int main()
{
	int a[4];
	a[0]=192;
	a[1]=168;
	a[2]=0;
	a[3]=4;
	string str=getIp(a);
	cout<<str<<endl;
	cout<<str.size()<<endl;
	/*char buffer[11];
	for(int i=0;i<str.size();i++)
	{
		buffer[i]=str[i];
	}
	for(int i=0;i<str.size();i++)
	{
		cout<<buffer[i];
	}*/
	vector<string> ret=getTokens(str,'.');
	for(int i=0;i<ret.size();i++)
	{
		cout<<ret.at(i)<<endl;
	}
}
