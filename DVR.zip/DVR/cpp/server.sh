g++ -o server.out server.cpp
./server.out
