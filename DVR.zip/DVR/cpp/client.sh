g++ -o client.out client.cpp
./client.out 192.168.0.4
